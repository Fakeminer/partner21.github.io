def main():
    import eel

    eel.init('web')

    eel.start('main.html')

    print('eel initialized')
if __name__ == "__main__":
    main()