﻿
       ███ ████ ████ █   █ ███ █   █ ████  ██  ███  ████ ████ █████
        █     █ █  █ ██ ██  █  ██  █ █    █  █ █  █ █  █ █      █
        █     █ ████ █ █ █  █  █ █ █ ████ █    ███  ████ ████   █
        █  █  █ █  █ █   █  █  █  ██ █    █  █ █  █ █  █ █      █
       ███  ██  █  █ █   █ ███ █   █ ████  ██  █  █ █  █ █      █

 	   You can visit me here: ijaminecraft.com
 	   Or check out my YouTube channel: youtube.com/user/IJAMinecraft
       ========================================================

       █  █ ████ █   █   █████ ████   █  █ ████ ████
       █  █ █  █ █ █ █     █   █  █   █  █ █    █   
       ████ █  █ █ █ █     █   █  █   █  █ ████ ████
       █  █ █  █ █ █ █     █   █  █   █  █    █ █   
       █  █ ████ █████     █   ████   ████ ████ ████

       This data pack is only for Minecraft version 1.15!
       In order to install this data pack, you need to unpack the zip archive with a program like 7Zip. 
       You will get a folder called 'ija-30-second-killer-machine'.

       Go into your Minecraft folder and in there, click on the folder called 'saves'.
       This folder contains all your worlds. Open the folder for the world where you 
       want to install this data pack. Then click on the folder 'datapacks' within
       there, and then place the 'ija-30-second-killer-machine' folder inside.

       Reload the world, and the data pack will be loaded and running.
       ========================================================

        ██   ██  ███  █ █ ███  ███  ███ █  █ █████
       █  █ █  █ █  █ █ █ █  █  █  █    █  █   █
       █    █  █ ███   █  ███   █  █ ██ ████   █ 
       █  █ █  █ █     █  █  █  █  █  █ █  █   █
        ██   ██  █     █  █  █ ███  ██  █  █   █

       For information on how and where you're allowed to use
       and showcase this work, please look at the txt file called
       'License' included in the downloaded zip archive.
       ========================================================
